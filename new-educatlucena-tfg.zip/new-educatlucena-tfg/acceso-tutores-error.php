<?php require_once('Connections/conexion.php'); ?>
<?php
mysql_select_db($database_conexion, $conexion);
$query_Consulta_Tutores = "SELECT * FROM tbltutores";
$Consulta_Tutores = mysql_query($query_Consulta_Tutores, $conexion) or die(mysql_error());
$row_Consulta_Tutores = mysql_fetch_assoc($Consulta_Tutores);
$totalRows_Consulta_Tutores = mysql_num_rows($Consulta_Tutores);
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>..:: EducatLucena. Acceso Padres/Madres ::..</title>
<link rel="shortcut icon" href="imagenes/favicon.ico">
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  
 <style>
    body {
      background-color: #f4f6f9;
    }

    .logo {
      width: 180px;
      margin: 30px auto 10px;
      display: block;
    }

    .login-card {
      max-width: 380px;
      margin: 20px auto 0;
      border-radius: 15px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      padding: 30px;
      background-color: white;
      transition: transform 0.2s;
    }

    .login-card:hover {
      transform: translateY(-4px);
    }

    footer {
	  background-color: #dee2e6;
	  color: #212529;
	  padding: 20px 0;
	  text-align: center;
	  margin-top: 200px;
	}
  </style>
</head>
<body>
<!-- Logo -->
  <header class="text-center my-4">
    <img src="imagenes/logotipo.png" alt="Logo EducaTLucena" class="img-fluid" style="max-width: 600px;" />
  </header>
<section>
<div id="logueo">
<h2 align="center"><strong>Lo sentimos, usuario y/o contrase&ntilde;a incorrectos.</strong></h2><br>
  <br>
<h2 align="center"><strong>Pulsa <a href="login-tutor.php">aqu&iacute;</a> para intentarlo de nuevo.</strong></h2><br>
<br>
</div>
</section>
 <!-- FOOTER -->
  <footer class="text-center text-muted py-3">
    &copy; 2025 EducaTLucena. Todos los derechos reservados.
  </footer>
  <!-- Año dinámico -->
  <script>
    document.getElementById("year").textContent = new Date().getFullYear();
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
mysql_free_result($Consulta_Tutores);
?>