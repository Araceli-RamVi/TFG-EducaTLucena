<?php require_once('../Connections/conexion.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "login.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
// *** Redirect if username exists
$MM_flag="MM_insert";
if (isset($_POST[$MM_flag])) {
  $MM_dupKeyRedirect="usuario-alumno-existe.php";
  $loginUsername = $_POST['usuario'];
  $LoginRS__query = sprintf("SELECT usuario FROM tblalumnos WHERE usuario=%s", GetSQLValueString($loginUsername, "text"));
  mysql_select_db($database_conexion, $conexion);
  $LoginRS=mysql_query($LoginRS__query, $conexion) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);

  //if there is a row in the database, the username was found - can not add the requested username
  if($loginFoundUser){
    $MM_qsChar = "?";
    //append the username to the redirect page
    if (substr_count($MM_dupKeyRedirect,"?") >=1) $MM_qsChar = "&";
    $MM_dupKeyRedirect = $MM_dupKeyRedirect . $MM_qsChar ."requsername=".$loginUsername;
    header ("Location: $MM_dupKeyRedirect");
	exit;
  }
}
error_reporting(E_ALL ^ E_NOTICE);
$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO tblalumnos (nombre, usuario, password, email, idcole, TelContacto, Ciudad, Observ, idtutor, idcurso, Lunes, Martes, Miercoles, Jueves, Viernes, ipusuario, username, horaentradal, horaentradam, horaentradax, horaentradaj, horaentradav, horasalidal, horasalidam, horasalidax, horasalidaj, horasalidav, idaula, activo) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['nombre'], "text"),
					   GetSQLValueString($_POST['usuario'], "text"),
                       GetSQLValueString(generaPass ($_POST['password']), "text"),
                       GetSQLValueString($_POST['email'], "text"),
					   GetSQLValueString($_POST['idcole'], "int"),
                       GetSQLValueString($_POST['TelContacto'], "text"),
                       GetSQLValueString($_POST['Ciudad'], "text"),
                       GetSQLValueString($_POST['Observ'], "text"),
                       GetSQLValueString($_POST['idtutor'], "int"),
					   GetSQLValueString($_POST['idcurso'], "int"),
					   GetSQLValueString($_POST['Lunes'], "int"),
					   GetSQLValueString($_POST['Martes'], "int"),
					   GetSQLValueString($_POST['Miercoles'], "int"),
					   GetSQLValueString($_POST['Jueves'], "int"),
					   GetSQLValueString($_POST['Viernes'], "int"),
					   GetSQLValueString(getRealIP($_POST['ipusuario']), "text"),
					   GetSQLValueString($_POST['username'], "text"),
					   GetSQLValueString($_POST['horaentradal'], "text"),
					   GetSQLValueString($_POST['horaentradam'], "text"),
					   GetSQLValueString($_POST['horaentradax'], "text"),
					   GetSQLValueString($_POST['horaentradaj'], "text"),
					   GetSQLValueString($_POST['horaentradav'], "text"),
					   GetSQLValueString($_POST['horasalidal'], "text"),
					   GetSQLValueString($_POST['horasalidam'], "text"),
					   GetSQLValueString($_POST['horasalidax'], "text"),
					   GetSQLValueString($_POST['horasalidaj'], "text"),
					   GetSQLValueString($_POST['horasalidav'], "text"),
					   GetSQLValueString($_POST['idaula'], "int"),
					   GetSQLValueString($_POST['activo'], "int"));

  mysql_select_db($database_conexion, $conexion);
  $Result1 = mysql_query($insertSQL, $conexion) or die(mysql_error());

  $insertGoTo = "listado-alumnos.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_conexion, $conexion);
$query_Consulta_Alumnos = "SELECT * FROM tblalumnos";
$Consulta_Alumnos = mysql_query($query_Consulta_Alumnos, $conexion) or die(mysql_error());
$row_Consulta_Alumnos = mysql_fetch_assoc($Consulta_Alumnos);
$totalRows_Consulta_Alumnos = mysql_num_rows($Consulta_Alumnos);

mysql_select_db($database_conexion, $conexion);
$query_Lista_Padres = "SELECT * FROM tbltutores ORDER BY tbltutores.nombre";
$Lista_Padres = mysql_query($query_Lista_Padres, $conexion) or die(mysql_error());
$row_Lista_Padres = mysql_fetch_assoc($Lista_Padres);
$totalRows_Lista_Padres = mysql_num_rows($Lista_Padres);

mysql_select_db($database_conexion, $conexion);
$query_Lista_Cursos = "SELECT * FROM tblcursos ORDER BY tblcursos.idcurso";
$Lista_Cursos = mysql_query($query_Lista_Cursos, $conexion) or die(mysql_error());
$row_Lista_Cursos = mysql_fetch_assoc($Lista_Cursos);
$totalRows_Lista_Cursos = mysql_num_rows($Lista_Cursos);

mysql_select_db($database_conexion, $conexion);
$query_Lista_Coles = "SELECT * FROM tblcolegios ORDER BY tblcolegios.idcole";
$Lista_Coles = mysql_query($query_Lista_Coles, $conexion) or die(mysql_error());
$row_Lista_Coles = mysql_fetch_assoc($Lista_Coles);
$totalRows_Lista_Coles = mysql_num_rows($Lista_Coles);

mysql_select_db($database_conexion, $conexion);
$query_Lista_Aulas = "SELECT * FROM tblaulas";
$Lista_Aulas = mysql_query($query_Lista_Aulas, $conexion) or die(mysql_error());
$row_Lista_Aulas = mysql_fetch_assoc($Lista_Aulas);
$totalRows_Lista_Aulas = mysql_num_rows($Lista_Aulas);
?>
<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
 <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>..:: Panel de Control - EducaTLucena ::..</title>
	<link rel="shortcut icon" href="../imagenes/favicon.ico">
	
   <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="assets/css/style.css" rel="stylesheet" />
    <style type="text/css">
body,td,th {
	font-family: Raleway, sans-serif;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
	color: #000000;
}
a:active {
	text-decoration: none;
}
footer {
	  background-color: #dee2e6;
	  color: #212529;
	  padding: 20px 0;
	  text-align: center;
	  margin-top: 200px;
}
    </style>
      <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<script language="JavaScript"> 
	function asegurar ()
	{
      rc = confirm("�Desea dar de alta este alumno?");
      return rc;
	}
	</script>
	<script>
	function asegurar2 ()
	  {
		  rc = confirm("�Seguro que desea eliminar definitivamente el alumno?");
		  return rc;
	  }
	</script>
	<script src="ckeditor/ckeditor.js"></script>
</head>
<body>
    <div id="wrapper">
      <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a  class="navbar-brand" href="#">Panel de Control 

                </a>
          </div>
      </nav> 
        <!-- /. SIDEBAR MENU (navbar-side) -->
        
        <?php include ("includes/menu.php"); ?>
        
        <!-- /. END SIDEBAR MENU (navbar-side) -->
               
        <div id="page-wrapper" class="page-wrapper-cls">
        

        
           <div id="page-inner">
                
                        
                <div class="row">
        
                    <div class="col-md-12">
					
						<img src="imagenes/logotipo.png" width="325" height="105" style="margin-left: 30px;"  />
        
                    	<h2>Bienvenido a EducaTLucena</h2>
        
                        <div class="alert alert-warning">
  <form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1" autocomplete="onclick">
        
                           <div id="accordion">
 		                   
                            <input name="usuario" type="hidden" id="usuario" value="<?php echo $_SESSION['MM_Username'];  ?>" />
                            
                      
                            <h4><strong>Gesti�n de Alumnos - Alta</strong></h4><hr>
                            
                            <div class="row"> 
                            
                            <div class="form-group col-md-3">
                            
                            <label>Nombre Completo:</label>
                            
                            <input name="nombre" class="form-control"  type="text" id="name" value="" size="25" placeholder="" required/>
                            
                            </div>
                            
                            <div class="form-group col-md-3">
                            
                            <label>Email:</label>
                            
                            <input name="email" class="form-control"  type="text" id="correo" value="" size="62" maxlength="62" placeholder="" required/>
                            
                            </div>
                                                
                            </div>
                            
                            <div class="row">
                                
                            <div class="form-group col-md-3">
                            
                            <label>Usuario:</label>
                            
                            <input name="usuario" class="form-control"  type="text" id="user" size="25" placeholder="" required/>
                            
                            </div>
                            
                           <div class="row">
                            
                            <div class="form-group col-md-3">
							
							<label>Ciudad:</label>
                            
                            <input name="Ciudad" class="form-control"  type="text" id="City" value="" size="25" placeholder="" required/>
                            
                            </div>
							</div>
                                                         
                            <div class="row">
                            
                            <div class="form-group col-md-3">
                            
                            <label>Tel�fono de Contacto:</label>
                            
                            <input name="TelContacto" class="form-control"  type="text" id="phone" value="" size="25" placeholder="" required/>
                            
                            </div>      

</div>							
							
                            <div class="row">
                            
                            <div class="form-group col-md-6">
							 
                            <label>Observaciones:</label>
                            
                            <textarea name="observaciones" class="form-control" rows="5" placeholder=""></textarea>
							
							<input type="hidden" name="username" id="username" value="<?php echo $_SESSION['MM_Username']?>">
							
							<input type="hidden" name="ipusuario" id="ipusuario">
                            
                            </div> 
                            
                            </div
                            
                            <input type="hidden" name="fechalta" value="">
      						
                            <input type="hidden" name="MM_insert" value="form1" />
                                              
                            </div>
							
							<br>
							
							<div class="row">
                            
                            <div class="form-group col-md-6">
								<label>Colegio: </label>
							
								<td align="left"><span id="school">
									<select name="idcole" id="idcole">
											<option value="" >Selecciona Colegio</option>
											<?php
								do {  
								?>
											<option value="<?php echo $row_Lista_Coles['idcole']?>"><?php echo $row_Lista_Coles['nomcolegio']?></option>
											<?php
								} while ($row_Lista_Coles = mysql_fetch_assoc($Lista_Coles));
								  $rows = mysql_num_rows($Lista_Coles);
								  if($rows > 0) {
									  mysql_data_seek($Lista_Coles, 0);
									  $row_Lista_Coles = mysql_fetch_assoc($Lista_Coles);
								  }
								?>
										  </select>
										  </span></td>
									  </tr>
									  
						
								 <label>Curso Actual: </label>
									<td>&nbsp;</td>
									<td align="left"><span id="actual">
									  <select name="idcurso" id="idcurso">
										<option value="" >Selecciona Curso Actual</option>
										<?php
							do {  
							?>
										<option value="<?php echo $row_Lista_Cursos['idcurso']?>"><?php echo $row_Lista_Cursos['nomcurso']?></option>
										<?php
							} while ($row_Lista_Cursos = mysql_fetch_assoc($Lista_Cursos));
							  $rows = mysql_num_rows($Lista_Cursos);
							  if($rows > 0) {
								  mysql_data_seek($Lista_Cursos, 0);
								  $row_Lista_Cursos = mysql_fetch_assoc($Lista_Cursos);
							  }
							?>
									  </select>
									  </span></td>
								  </tr>
								<label>Padre/Madre: </label>
							  </tr>
							  <tr valign="baseline">
								 <td align="left"><span id="tutor">
								  <select name="idtutor" id="idtutor">
									<option value="">Selecciona Padre/Madre</option>
									<?php
						do {  
						?>
									<option value="<?php echo $row_Lista_Padres['idtutor']?>"><?php echo $row_Lista_Padres['nombre']?></option>
									<?php
						} while ($row_Lista_Padres = mysql_fetch_assoc($Lista_Padres));
						  $rows = mysql_num_rows($Lista_Padres);
						  if($rows > 0) {
							  mysql_data_seek($Lista_Padres, 0);
							  $row_Lista_Padres = mysql_fetch_assoc($Lista_Padres);
						  }
						?>
								  </select>
								  </span></td>
							  </tr>
					</div>
			</div>
	  
 <tr valign="baseline">
        <td align="left" nowrap> <strong>Marcar si Alumno esta Activo:</strong>
          <input class="diasemana" name="activo" type="checkbox" id="activo" value="1" <?php if (!(strcmp($row_Consulta_Alumnos['activo'],1))) {echo "checked=\"checked\"";}?>></td>
        <td align="left" nowrap>&nbsp;</td>
        <td align="left" nowrap> <strong>Aula:</strong>
          <select name="idaula" id="idaula">
            <option value="" >Selecciona Aula</option>
            <?php
do {  
?>
            <option value="<?php echo $row_Lista_Aulas['idaula']?>"><?php echo $row_Lista_Aulas['nomaula']?></option>
            <?php
} while ($row_Lista_Aulas = mysql_fetch_assoc($Lista_Aulas));
  $rows = mysql_num_rows($Lista_Aulas);
  if($rows > 0) {
      mysql_data_seek($Lista_Aulas, 0);
	  $row_Lista_Aulas = mysql_fetch_assoc($Lista_Aulas);
  }
?>
          </select></td>
      </tr>

                            
<br><br>

      
      <tr valign="baseline">
        <td colspan="3" align="left" nowrap>
          <table width="50%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td colspan="5" align="center" bgcolor="#CCCCCC"> <strong>DIAS DE ASISTENCIA A CLASES</strong></td>
              </tr>
            <tr>
              <td align="center">&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr><br/>
              <td width="100" align="center"><input class="diasemana" name="Lunes" type="checkbox" id="Lunes" value="1" <?php if (!(strcmp($row_Consulta_Alumnos['Lunes'],0))) {echo "checked=\"checked\"";}?>>
          Lunes</td>
              <td width="100" align="center"><input class="diasemana" name="Martes" type="checkbox" id="Martes" value="1" <?php if (!(strcmp($row_Consulta_Alumnos['Martes'],0))) {echo "checked=\"checked\"";} ?>>
          Martes</td>
              <td width="100" align="center"><input class="diasemana" name="Miercoles" type="checkbox" id="Miercoles" value="1" <?php if (!(strcmp($row_Consulta_Alumnos['Miercoles'],0))) {echo "checked=\"checked\"";} ?>>
          Mi&eacute;rcoles</td>
              <td width="100" align="center"><input class="diasemana" name="Jueves" type="checkbox" id="Jueves" value="1" <?php if (!(strcmp($row_Consulta_Alumnos['Jueves'],0))) {echo "checked=\"checked\"";} ?>>
          Jueves</td>
              <td width="100"align="center"><input class="diasemana" name="Viernes" type="checkbox" id="Viernes" value="1" <?php if (!(strcmp($row_Consulta_Alumnos['Viernes'],0))) {echo "checked=\"checked\"";} ?>>
          Viernes</td>
            </tr>
            <tr>
              <td colspan="5" align="center">&nbsp;</td>
            </tr>
            <tr>
              <td colspan="5" align="center" bgcolor="#CCCCCC"> <strong>HORARIO DE ENTRADA</strong></td>
              </tr>
            <tr>
              <td align="center">&nbsp;</td>
              <td align="center">&nbsp;</td>
              <td align="center">&nbsp;</td>
              <td align="center">&nbsp;</td>
              <td align="center">&nbsp;</td>
            </tr>
            <tr>
            
            
              <td align="center"><select name="horaentradal" id="horaentradal">
                <option>-</option>
<option value="15:30">15:30</option>
<option value="16:00">16:00</option>
<option value="16:30">16:30</option>
<option value="17:00">17:00</option>
<option value="17:30">17:30</option>
<option value="18:00">18:00</option>
<option value="18:30">18:30</option>
<option value="19:00">19:00</option>
<option value="19:30">19:30</option>
<option value="20:00">20:00</option>
              </select></td>
              
              
              <td align="center"><select name="horaentradam" id="horaentradam">
                <option>-</option>
          <option value="15:30">15:30</option>
          <option value="16:00">16:00</option>
          <option value="16:30">16:30</option>
          <option value="17:00">17:00</option>
          <option value="17:30">17:30</option>
          <option value="18:00">18:00</option>
          <option value="18:30">18:30</option>
          <option value="19:00">19:00</option>
          <option value="19:30">19:30</option>
          <option value="20:00">20:00</option>
        </select></td>
              <td align="center"><select name="horaentradax" id="horaentradax">
                <option>-</option>
          <option value="15:30">15:30</option>
          <option value="16:00">16:00</option>
          <option value="16:30">16:30</option>
          <option value="17:00">17:00</option>
          <option value="17:30">17:30</option>
          <option value="18:00">18:00</option>
          <option value="18:30">18:30</option>
          <option value="19:00">19:00</option>
          <option value="19:30">19:30</option>
          <option value="20:00">20:00</option>
        </select></td>
              <td align="center"><select name="horaentradaj" id="horaentradaj">
                <option>-</option>
          <option value="15:30">15:30</option>
          <option value="16:00">16:00</option>
          <option value="16:30">16:30</option>
          <option value="17:00">17:00</option>
          <option value="17:30">17:30</option>
          <option value="18:00">18:00</option>
          <option value="18:30">18:30</option>
          <option value="19:00">19:00</option>
          <option value="19:30">19:30</option>
          <option value="20:00">20:00</option>
        </select></td>
              <td align="center"><select name="horaentradav" id="horaentradav">
                <option>-</option>
          <option value="15:30">15:30</option>
          <option value="16:00">16:00</option>
          <option value="16:30">16:30</option>
          <option value="17:00">17:00</option>
          <option value="17:30">17:30</option>
          <option value="18:00">18:00</option>
          <option value="18:30">18:30</option>
          <option value="19:00">19:00</option>
          <option value="19:30">19:30</option>
          <option value="20:00">20:00</option>
        </select></td>
            </tr>
            <tr>
              <td colspan="5" align="center">&nbsp;</td>
            </tr>
            <tr>
              <td colspan="5" align="center" bgcolor="#CCCCCC"><strong>HORARIO DE SALIDA</strong></td>
              </tr>
            <tr>
              <td align="center">&nbsp;</td>
              <td align="center">&nbsp;</td>
              <td align="center">&nbsp;</td>
              <td align="center">&nbsp;</td>
              <td align="center">&nbsp;</td>
            </tr>
            <tr>
              <td align="center"><select name="horasalidal" id="horasalidal">
                <option>-</option>
<option value="16:30">16:30</option>
<option value="17:00">17:00</option>
<option value="17:30">17:30</option>
<option value="18:00">18:00</option>
<option value="18:30">18:30</option>
<option value="19:00">19:00</option>
<option value="19:30">19:30</option>
<option value="20:00">20:00</option>
<option value="20:30">20:30</option>
<option value="21:00">21:00</option>
              </select></td>
              
              
              <td align="center"><select name="horasalidam" id="horasalidam">
                <option>-</option>
          <option value="16:30">16:30</option>
          <option value="17:00">17:00</option>
          <option value="17:30">17:30</option>
          <option value="18:00">18:00</option>
          <option value="18:30">18:30</option>
          <option value="19:00">19:00</option>
          <option value="19:30">19:30</option>
          <option value="20:00">20:00</option>
          <option value="20:30">20:30</option>
          <option value="21:00">21:00</option>
        </select></td>
              <td align="center"><select name="horasalidax" id="horasalidax">
                <option>-</option>
          <option value="16:30">16:30</option>
          <option value="17:00">17:00</option>
          <option value="17:30">17:30</option>
          <option value="18:00">18:00</option>
          <option value="18:30">18:30</option>
          <option value="19:00">19:00</option>
          <option value="19:30">19:30</option>
          <option value="20:00">20:00</option>
          <option value="20:30">20:30</option>
		  <option value="21:00">21:00</option>
        </select></td>
              <td align="center"><select name="horasalidaj" id="horasalidaj">
                <option>-</option>
          <option value="16:30">16:30</option>
          <option value="17:00">17:00</option>
          <option value="17:30">17:30</option>
          <option value="18:00">18:00</option>
          <option value="18:30">18:30</option>
          <option value="19:00">19:00</option>
          <option value="19:30">19:30</option>
          <option value="20:00">20:00</option>
          <option value="20:30">20:30</option>
		  <option value="21:00">21:00</option>
        </select></td>
              <td align="center"><select name="horasalidav" id="horasalidav">
                <option>-</option>
          <option value="16:30">16:30</option>
          <option value="17:00">17:00</option>
          <option value="17:30">17:30</option>
          <option value="18:00">18:00</option>
          <option value="18:30">18:30</option>
          <option value="19:00">19:00</option>
          <option value="19:30">19:30</option>
          <option value="20:00">20:00</option>
          <option value="20:30">20:30</option>
		  <option value="21:00">21:00</option>
        </select></td>
            </tr>
          </table>
          </td>
        </tr>
      <tr valign="baseline">
        <td colspan="3" align="left" nowrap></td>
        </tr>
      <tr valign="baseline">
        <td colspan="3" align="right" nowrap>&nbsp;</td>
        </tr>
      <tr valign="baseline">
        <td colspan="3" align="left" nowrap></td>
      </tr>
	  
	  <br><br>
	  
      <tr valign="baseline">
        <td colspan="3" align="left" nowrap>&nbsp;</td>
      </tr>
	  
      <tr valign="baseline">
        <td nowrap align="right"><input type="hidden" name="ipusuario" id="ipusuario"></td>
        <td align="right">&nbsp;</td>
        <td align="right"><input class="botonaltas" type="submit" onclick="javascript:return asegurar();" value="Insertar Alumno"></td>
      </tr>
    </table>
    <input name="username" type="hidden" id="username" value="<?php echo $_SESSION['MM_Username']?>">
    <input type="hidden" name="fechalta" value="">
    
    <input type="hidden" name="MM_insert" value="form1">
  </form>
    </div>    
</div>
<br>


<div class="clearfix"></div>
  <footer class="text-center text-muted py-3">
    &copy; 2025 EducaTLucena. Todos los derechos reservados.
  </footer>
  <!-- A�o din�mico -->
  <script>
    document.getElementById("year").textContent = new Date().getFullYear();
  </script>
  
    
    <!-- /. FOOTER  -->
    
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
</div>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("name", "none", {validateOn:["blur"]});
var sprytextfield2 = new Spry.Widget.ValidationTextField("username", "none", {validateOn:["blur"]});
// var sprytextfield3 = new Spry.Widget.ValidationTextField("pass", "none", {validateOn:["blur"]});
var spryselect1 = new Spry.Widget.ValidationSelect("school", {validateOn:["blur"]});
var sprytextfield4 = new Spry.Widget.ValidationTextField("phone", "none", {validateOn:["blur"]});
var spryselect2 = new Spry.Widget.ValidationSelect("actual", {validateOn:["blur"]});
var sprytextfield5 = new Spry.Widget.ValidationTextField("city", "none", {validateOn:["blur"]});
var spryselect3 = new Spry.Widget.ValidationSelect("tutor", {validateOn:["blur"]});
</script>

</body>
</html>
<?php
mysql_free_result($Consulta_Alumnos);

mysql_free_result($Lista_Padres);

mysql_free_result($Lista_Cursos);

mysql_free_result($Lista_Coles);

mysql_free_result($Lista_Aulas);
?>
