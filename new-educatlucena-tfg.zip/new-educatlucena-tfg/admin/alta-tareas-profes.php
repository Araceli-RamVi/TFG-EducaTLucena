<?php require_once('../Connections/conexion.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  @session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "../..\index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
mysql_select_db($database_conexion, $conexion);
$query_Lista_Profesores = "SELECT * FROM tblprofesores WHERE idprof>1";
$Lista_Profesores = mysql_query($query_Lista_Profesores, $conexion) or die(mysql_error());
$row_Lista_Profesores = mysql_fetch_assoc($Lista_Profesores);
$totalRows_Lista_Profesores = mysql_num_rows($Lista_Profesores);

error_reporting(E_ALL ^ E_NOTICE);


$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
?>
<?php
$fecha1 = date('Y-m-d', strtotime($_POST['fechamensaje']));


if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO tblagendaprofes ( idprof, mensaje, fechamensaje, usuario, ipusuario, idenvia) VALUES (%s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['idprof'], "int"),
                       GetSQLValueString($_POST['mensaje'], "text"),
                       GetSQLValueString($fecha1, "date"),
                       GetSQLValueString($_POST['usuario'], "text"),
                       GetSQLValueString(getRealIP($_POST['ipusuario']), "text"),
					   GetSQLValueString($_POST['idenvia'], "int"));

  mysql_select_db($database_conexion, $conexion);
  $Result1 = mysql_query($insertSQL, $conexion) or die(mysql_error());

  $insertGoTo = "listado-tareas-profes.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "../..\index.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conexion, $conexion);
$query_Listado_Usuarios = "SELECT * FROM tblprofesores";
$Listado_Usuarios = mysql_query($query_Listado_Usuarios, $conexion) or die(mysql_error());
$row_Listado_Usuarios = mysql_fetch_assoc($Listado_Usuarios);
$totalRows_Listado_Usuarios = mysql_num_rows($Listado_Usuarios);
?>
<!DOCTYPE html>
<html>
<head>
 <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>..:: Panel de Control - EducaTLucena ::..</title>
	<link rel="shortcut icon" href="../imagenes/favicon.ico">
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="assets/css/style.css" rel="stylesheet" />
    <style type="text/css">

body,td,th {
	font-family: Raleway, sans-serif;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
	color: #000000;
}
a:active {
	text-decoration: none;
}
footer {
	  background-color: #dee2e6;
	  color: #212529;
	  padding: 20px 0;
	  text-align: center;
	  margin-top: 200px;
}
    </style>
      <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<script  language="JavaScript">
	$(function() {
		$( "#datepicker" ).datepicker({
			showWeek: false,
			firstDay: 1
		});
	});
</script>
<script language="JavaScript"> 
function asegurar ()
  {
      rc = confirm("¿Desea dar de alta esta tarea?");
      return rc;
  }
</script>
</head>
<body>
    <div id="wrapper">
      <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a  class="navbar-brand" href="#">Panel de Control 

                </a>
          </div>
      </nav> 
        <!-- /. SIDEBAR MENU (navbar-side) -->
        
        <?php include ("includes/menu.php"); ?>
        
        <!-- /. END SIDEBAR MENU (navbar-side) -->
               
        <div id="page-wrapper" class="page-wrapper-cls">
        
           <div id="page-inner">
                       
                <div class="row">
        
                    <div class="col-md-12">
					
						<img src="imagenes/logotipo.png" width="325" height="105" style="margin-left: 30px;"  />
        
                    	<h2>Bienvenido a EducaTLucena.</h2>
        
                        <div class="alert alert-warning">
        
                           <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
    <table width="510" align="center">
      <tr valign="baseline">
        <td width="240" align="right" nowrap>&nbsp;</td>
        <td width="14">&nbsp;</td>
        <td width="240">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="3" align="center" valign="middle" nowrap><h3><strong>Alta de Tareas</strong></h3></td>
      </tr>
      <tr valign="baseline">
        <td colspan="3" align="left" nowrap>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="left">Destinatario:</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="3" align="left" nowrap><span id="teacher">
          <select name="idprof" id="idprof">
            <option value="" >Selecciona Profesor</option>
            <?php
do {  
?>
            <option value="<?php echo $row_Lista_Profesores['idprof']?>"><?php echo $row_Lista_Profesores['nombre']?></option>
            <?php
} while ($row_Lista_Profesores = mysql_fetch_assoc($Lista_Profesores));
  $rows = mysql_num_rows($Lista_Profesores);
  if($rows > 0) {
      mysql_data_seek($Lista_Profesores, 0);
	  $row_Lista_Alumnos = mysql_fetch_assoc($Lista_Profesores);
  }
?>
          </select>
          </span></td>
        </tr>
      <tr valign="baseline">
        <td nowrap align="left">Mensaje:</td>
        <td align="left">&nbsp;</td>
        <td align="left">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="3" align="left" nowrap><span id="message">
          <textarea name="mensaje" cols="73" rows="5"></textarea>
          </span><script>/*CKEDITOR.replace( 'mensaje' );*/</script></td>
        </tr>
      <tr valign="baseline">
        <td nowrap align="left">Fecha del mensaje:</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="left"><span id="datemes">
        
          <input type="date" class="form-control" name="fechamensaje" id="datepicker" value="" size="10">
</span></td>
        <td align="right">&nbsp;</td>
        <td align="right">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">&nbsp;</td>
        <td align="right">&nbsp;</td>
        <td align="right"><input type="submit" onclick="asegurar()" value="Insertar registro"></td>
      </tr>
    </table>
    <input type="hidden" name="usuario" id="usuario" value="<?php echo $_SESSION['MM_Username']?>">
    <input type="hidden" name="fechalta" value="">
    <input type="hidden" name="ipusuario" id="ipusuario" value="">
    
    <input type="hidden" name="MM_insert" value="form1">
    <input type="hidden" name="idenvia" id="idenvia" value="<?php echo $_SESSION['MM_Id'] ?>">
</form>
        
                            </p> 
        
                        </div>
        
                    </div>
        
                </div>

            </div>
    
            <!-- /. PAGE INNER  -->
    
        </div>
    
        <!-- /. PAGE WRAPPER  -->
    
    </div>
    
    <!-- /. WRAPPER  -->
	
	 <!-- /. FOOTER  -->
    
   <footer class="text-center text-muted py-3">
    &copy; 2025 EducaTLucena. Todos los derechos reservados.
  </footer>
  <!-- Año dinámico -->
  <script>
    document.getElementById("year").textContent = new Date().getFullYear();
  </script>
  
    
    <!-- /. FOOTER  -->
    
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>

</body>
</html>
<?php
mysql_free_result($Listado_Usuarios);
?>
