-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 09-07-2025 a las 12:55:36
-- Versión del servidor: 5.6.17
-- Versión de PHP: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `educa_t_lucena`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblagendaprofes`
--

CREATE TABLE IF NOT EXISTS `tblagendaprofes` (
  `idagenda` int(11) NOT NULL AUTO_INCREMENT,
  `idprof` int(11) DEFAULT NULL,
  `mensaje` text COLLATE utf8_spanish_ci NOT NULL,
  `fechamensaje` date NOT NULL,
  `usuario` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `fechalta` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ipusuario` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `usuariomod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `fechamod` datetime NOT NULL,
  `ipusuariomod` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `idenvia` int(11) NOT NULL,
  PRIMARY KEY (`idagenda`),
  KEY `idprodestino` (`idprof`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=17 ;

--
-- Volcado de datos para la tabla `tblagendaprofes`
--

INSERT INTO `tblagendaprofes` (`idagenda`, `idprof`, `mensaje`, `fechamensaje`, `usuario`, `fechalta`, `ipusuario`, `usuariomod`, `fechamod`, `ipusuariomod`, `idenvia`) VALUES
(3, 4, 'AAAAAAAAAAAA', '2024-11-18', 'Araceli', '2024-11-18 21:31:36', '::1', '', '0000-00-00 00:00:00', '', 4),
(5, 10, 'fffff', '1970-01-01', 'Araceli', '2025-06-21 17:50:25', '::1', '', '0000-00-00 00:00:00', '', 2),
(9, 2, 'No es para ti este mensaje. Pero te lo puedes quedar porque eres guapa', '2025-06-22', 'Araceli', '2025-06-22 16:14:12', '::1', 'Araceli', '2025-06-22 18:15:18', '::1', 2),
(13, 13, 'Debes darle clase a Pablo durante la semana del  7 al 11 de Julio', '2025-07-01', 'Araceli', '2025-07-01 10:30:32', '::1', '', '0000-00-00 00:00:00', '', 11),
(14, 13, 'Necesito que corrijas algunas tareas para ayudarme ya que tengo el doble de alumnos por las vacaciones de Ãngela.', '2025-07-02', 'Araceli', '2025-07-02 19:45:40', '::1', 'Araceli', '2025-07-07 17:43:57', '::1', 11),
(15, 14, 'El alumno Antonio Martínez vendrá esta semana, además de los días que viene, los martes y jueves a su misma hora.', '2025-07-07', 'Araceli', '2025-07-04 18:54:49', '::1', '', '0000-00-00 00:00:00', '', 11),
(16, 11, 'Esta semana del 7 al 11 de Julio debes atender a los alumnos de Angela, que se ha cogido las vacaciones, he mirado y no se solapan en horario con los tuyos.', '2025-07-04', 'Eli', '2025-07-06 14:52:49', '::1', 'Araceli', '2025-07-08 17:06:49', '::1', 14);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblalumnos`
--

CREATE TABLE IF NOT EXISTS `tblalumnos` (
  `idalumno` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(75) COLLATE utf8_spanish_ci NOT NULL,
  `usuario` varchar(15) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `password` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(75) COLLATE utf8_spanish_ci DEFAULT NULL,
  `Ciudad` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `TelContacto` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `Observ` text COLLATE utf8_spanish_ci,
  `fechalta` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fechamodif` datetime DEFAULT NULL,
  `idtutor` int(11) DEFAULT NULL,
  `codeducat` varchar(17) COLLATE utf8_spanish_ci DEFAULT 'AlumnaTLucena2015',
  `idcurso` int(11) DEFAULT NULL,
  `idcole` int(11) DEFAULT NULL,
  `Lunes` tinyint(1) DEFAULT '0',
  `Martes` tinyint(1) DEFAULT '0',
  `Miercoles` tinyint(1) DEFAULT '0',
  `Jueves` tinyint(1) DEFAULT '0',
  `Viernes` tinyint(1) DEFAULT '0',
  `ipusuario` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `username` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `horaentradal` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `horaentradam` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `horaentradax` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `horaentradaj` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `horaentradav` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `horasalidal` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `horasalidam` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `horasalidax` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `horasalidaj` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `horasalidav` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `ipusuariomod` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `usernamemod` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `idaula` int(11) NOT NULL,
  `activo` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idalumno`),
  KEY `idtutor` (`idtutor`),
  KEY `idcurso` (`idcurso`),
  KEY `idcole` (`idcole`),
  KEY `idaula` (`idaula`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `tblalumnos`
--

INSERT INTO `tblalumnos` (`idalumno`, `nombre`, `usuario`, `password`, `email`, `Ciudad`, `TelContacto`, `Observ`, `fechalta`, `fechamodif`, `idtutor`, `codeducat`, `idcurso`, `idcole`, `Lunes`, `Martes`, `Miercoles`, `Jueves`, `Viernes`, `ipusuario`, `username`, `horaentradal`, `horaentradam`, `horaentradax`, `horaentradaj`, `horaentradav`, `horasalidal`, `horasalidam`, `horasalidax`, `horasalidaj`, `horasalidav`, `ipusuariomod`, `usernamemod`, `idaula`, `activo`) VALUES
(1, 'Antonio Martínez', 'alu.antonio.mar', 'zzgpJSUumkVu', 'antonmartin@gmail.com', 'Lucena', '654123987', NULL, '2025-06-24 19:36:17', NULL, 1, 'AlumnaTLucena2015', 5, 1, 1, NULL, 1, NULL, NULL, '::1', 'Araceli', '16:30', '-', '16:30', '-', '-', '18:00', '-', '18:00', '-', '-', NULL, NULL, 2, 1),
(2, 'Antonio Lomas Paz', 'alu.antonio.lom', '994DYC76q0Sn', 'antoniolomapaz@gmail.com', 'Lucena', '957500623', '<p>Alumno con TDAH</p>\r\n', '2025-06-25 18:24:28', '2025-07-03 19:51:27', 2, 'AlumnaTLucena2015', 6, 4, NULL, 1, NULL, 1, 1, '::1', 'Araceli', '-', '16:00', '-', '16:00', '16:00', '-', '18:00', '-', '18:00', '18:00', '::1', 'Araceli', 1, 1),
(3, 'Pablo Gutierrez Alba', 'alu.pablo.gutia', 'mb9oUexbblEY', 'educatlucena@gmail.com', 'Lucena', '659852746', NULL, '2025-06-26 10:45:11', '2025-07-04 12:39:23', 2, 'AlumnaTLucena2015', 7, 11, NULL, 1, NULL, 1, NULL, '::1', 'Araceli', '-', '16:30', '-', '17:00', '-', '-', '18:30', '-', '19:00', '-', '::1', 'Araceli', 2, 1),
(4, 'Manuel Contreras Aguilar', 'alu.manuconagui', 'm3XWYtvcjolt', 'educatlucena@gmail.com', 'Lucena', '957502255', NULL, '2025-06-26 11:19:45', NULL, 2, 'AlumnaTLucena2015', 6, 1, 1, NULL, NULL, NULL, NULL, '::1', 'Araceli', '17:30', '-', '-', '-', '-', '20:00', '-', '-', '-', '-', NULL, NULL, 3, 1),
(5, 'Bernardo Clarisa Alma', 'alu.bernardo.cl', 'UWCowUSs62WQ', 'bernar.clarial@gmail.com', 'Lucena', '668951743', NULL, '2025-07-03 15:53:08', '2025-07-03 20:45:52', 3, 'AlumnaTLucena2015', 2, 2, NULL, 1, NULL, 1, 1, '::1', 'Araceli', '-', '16:00', '-', '16:00', '16:00', '-', '17:30', '-', '17:30', '17:30', '::1', 'Araceli', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblasignaturas`
--

CREATE TABLE IF NOT EXISTS `tblasignaturas` (
  `idasignat` int(11) NOT NULL AUTO_INCREMENT,
  `nombreasignat` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idasignat`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=14 ;

--
-- Volcado de datos para la tabla `tblasignaturas`
--

INSERT INTO `tblasignaturas` (`idasignat`, `nombreasignat`) VALUES
(1, 'Matemáticas'),
(2, 'Lengua'),
(3, 'Sociales'),
(4, 'Naturales'),
(5, 'Inglés'),
(6, 'Música'),
(7, 'Historia'),
(8, 'Biología'),
(9, 'Física y Química'),
(10, 'Literatura'),
(11, 'Tecnología'),
(12, 'Informática'),
(13, 'Cuaderno Verano');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblaulas`
--

CREATE TABLE IF NOT EXISTS `tblaulas` (
  `idaula` int(11) NOT NULL AUTO_INCREMENT,
  `nomaula` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idaula`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `tblaulas`
--

INSERT INTO `tblaulas` (`idaula`, `nomaula`) VALUES
(1, 'Aula-1 (Eli)'),
(2, 'Aula 2 (Ara)'),
(3, 'Aula 3 (Multiprofe)'),
(4, 'Aula 4 (Inglés)');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblcalificaciones`
--

CREATE TABLE IF NOT EXISTS `tblcalificaciones` (
  `idcalificacion` int(11) NOT NULL AUTO_INCREMENT,
  `Fechaexamen` date NOT NULL,
  `idasignat` int(11) NOT NULL,
  `idalumno` int(11) NOT NULL,
  `prepara` text COLLATE utf8_spanish_ci NOT NULL,
  `Nota` varchar(5) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fallos` text COLLATE utf8_spanish_ci NOT NULL,
  `username` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `usernamemod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `fechalta` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fechamodif` datetime NOT NULL,
  `ipusuario` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `ipusuariomod` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idcalificacion`),
  KEY `idasignat` (`idasignat`),
  KEY `idalumno` (`idalumno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblcolegios`
--

CREATE TABLE IF NOT EXISTS `tblcolegios` (
  `idcole` int(11) NOT NULL AUTO_INCREMENT,
  `nomcolegio` varchar(75) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idcole`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=15 ;

--
-- Volcado de datos para la tabla `tblcolegios`
--

INSERT INTO `tblcolegios` (`idcole`, `nomcolegio`) VALUES
(1, 'Colegio La Purísima'),
(2, 'Colegio Ntra. Sra. de Araceli (El Parque)'),
(3, 'Colegio El Valle'),
(4, 'Colegio Barahona de Soto'),
(5, 'Colegio El Prado'),
(6, 'Colegio Antonio Machado (La Estrella)'),
(7, 'Colegio San José de Calasanz'),
(8, 'Colegio Al Yussana'),
(9, 'Colegio Ntra. Sra. del Carmen'),
(10, 'I.E.S. Clara Campoamor'),
(11, 'I.E.S. Marqués de Comares'),
(12, 'I.E.S. Juan de Aréjula'),
(13, 'I.E.S. Sierra de Aras'),
(14, 'I.E.S. Miguel de Cervantes');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblcursos`
--

CREATE TABLE IF NOT EXISTS `tblcursos` (
  `idcurso` int(11) NOT NULL AUTO_INCREMENT,
  `nomcurso` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idcurso`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=13 ;

--
-- Volcado de datos para la tabla `tblcursos`
--

INSERT INTO `tblcursos` (`idcurso`, `nomcurso`) VALUES
(1, 'Curso 1º Primaria'),
(2, 'Curso 2º Primaria'),
(3, 'Curso 3º Primaria'),
(4, 'Curso 4º Primaria'),
(5, 'Curso 5º Primaria'),
(6, 'Curso 6º Primaria'),
(7, 'Curso 1º ESO'),
(8, 'Curso 2º ESO'),
(9, 'Curso 3º ESO'),
(10, 'Curso 4º ESO'),
(11, 'Curso 1º Bachillerato'),
(12, 'Curso 2º Bachillerato');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbldatos`
--

CREATE TABLE IF NOT EXISTS `tbldatos` (
  `id_datos` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `url` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`id_datos`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblprofesores`
--

CREATE TABLE IF NOT EXISTS `tblprofesores` (
  `idprof` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(75) COLLATE utf8_spanish_ci NOT NULL,
  `usuario` varchar(15) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `password` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(75) COLLATE utf8_spanish_ci NOT NULL,
  `fechalta` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `fechamodif` datetime DEFAULT NULL,
  `observaciones` text COLLATE utf8_spanish_ci,
  `codeducat` varchar(10) COLLATE utf8_spanish_ci DEFAULT 'EducaT2015',
  `telefono` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `username` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `usernamemod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `ipusuario` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `ipusuariomod` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `nivelprof` enum('Admin','Profesor','Alumno','') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idprof`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=16 ;

--
-- Volcado de datos para la tabla `tblprofesores`
--

INSERT INTO `tblprofesores` (`idprof`, `nombre`, `usuario`, `password`, `email`, `fechalta`, `fechamodif`, `observaciones`, `codeducat`, `telefono`, `username`, `usernamemod`, `ipusuario`, `ipusuariomod`, `nivelprof`) VALUES
(1, 'ADMINISTRADOR', 'ADMINISTRADOR', 'Admin!2016', 'rogelio@soporte-informatica.com', '2016-08-03 19:11:09', NULL, 'Es superusuario... Plenos permisos para todo.', 'EducaT2015', '657982788', '', '', NULL, '', 'Admin'),
(11, 'Araceli Ramírez Vigo', 'Araceli', 'Ara1409', 'profesorafp.araceli@gmail.com', NULL, '2025-07-04 20:47:30', NULL, 'EducaT2015', '666623685', 'Araceli', 'Araceli', '::1', '::1', 'Admin'),
(12, 'Alberto Pérez Ramírez', 'alberto.perez', 'Alb.Per@2025', 'alberto.perez@gmail.com', NULL, NULL, NULL, 'EducaT2015', '654123987', 'Araceli', '', '::1', '', 'Admin'),
(13, 'Juan Antonio Pérez Ramírez', 'p.juant.perez@2', 'juanpram-2025', 'jperram28@gmail.com', NULL, NULL, NULL, 'EducaT2015', '669665662', 'Araceli', '', '::1', '', 'Admin'),
(14, 'Elisabeth Moyano Osuna', 'Eli', 'Eli@Mo-Os%2025', 'eli_lucena21@hotmail.com', NULL, '2025-07-07 19:09:34', NULL, 'EducaT2015', '618041026', 'Araceli', 'Araceli', '::1', '::1', 'Admin'),
(15, 'Claudia Blanca González', 'Claudia', 'UNIR@Claudia%2025', '', '2025-07-09 10:48:22', NULL, NULL, 'EducaT2015', '', '', '', NULL, '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbltareasalumnos`
--

CREATE TABLE IF NOT EXISTS `tbltareasalumnos` (
  `idtarea` int(11) NOT NULL AUTO_INCREMENT,
  `idalumno` int(11) NOT NULL,
  `idasignatura` int(11) NOT NULL,
  `adjunto` varchar(200) COLLATE utf8_spanish_ci DEFAULT NULL,
  `comentarios` text COLLATE utf8_spanish_ci,
  `acercadelaweb` varchar(150) COLLATE utf8_spanish_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `username` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `fechalta` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ipusuario` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `usernamemod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `fechamodif` date NOT NULL,
  `ipusuariomod` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idtarea`),
  KEY `idalumno` (`idalumno`),
  KEY `idasignatura` (`idasignatura`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=13 ;

--
-- Volcado de datos para la tabla `tbltareasalumnos`
--

INSERT INTO `tbltareasalumnos` (`idtarea`, `idalumno`, `idasignatura`, `adjunto`, `comentarios`, `acercadelaweb`, `url`, `username`, `fechalta`, `ipusuario`, `usernamemod`, `fechamodif`, `ipusuariomod`) VALUES
(10, 3, 13, '03072025-1741-Cuaderno-Verano-1ºESO.pdf', 'Realiza dos página diaria y juega en la web de inglés, escucha también canciones que te gusten en inglés.', 'Web para repasar inglés de 1º ESO', 'https://www.ejerciciosinglesonline.com/cursos/1%C2%BA-eso/cuaderno-ejercicios-eso/', 'Araceli', '2025-07-03 15:44:31', '::1', 'Araceli', '2025-07-04', '::1'),
(11, 1, 1, '07072025-1803-Trabajo_vacaciones_6o_Matematicas.pdf', 'Realiza a diario una página del cuadernillo y juega en la web que te he puesto.', 'Web de actividades de Mates para 6º Primaria', 'https://www.matematicasonline.es/primaria6/6primaria1.html', 'Araceli', '2025-07-07 16:04:28', '::1', '', '0000-00-00', ''),
(12, 5, 2, '07072025-1805-VACACIONES  2ºPRIM.pdf', 'Realiza cada día 2 hojas del cuaderno de verano y juega como quieras en la web que tiene un poco de todo.', 'Web de actividades para todos los cursos', 'https://www.todoinclusion.com/Ciencias-Nat-Soc-E-P-Material/', 'Araceli', '2025-07-07 16:06:23', '::1', '', '0000-00-00', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbltrabajosalumnos`
--

CREATE TABLE IF NOT EXISTS `tbltrabajosalumnos` (
  `idtrabajo` int(11) NOT NULL AUTO_INCREMENT,
  `idalumno` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `trabajos` text COLLATE utf8_spanish_ci NOT NULL,
  `comportamientos` text COLLATE utf8_spanish_ci NOT NULL,
  `usuario` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `ipusuario` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `fechamodif` date NOT NULL,
  `usuariomod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `ipusuariomodif` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `idprof` int(11) NOT NULL,
  PRIMARY KEY (`idtrabajo`),
  KEY `idalumno` (`idalumno`),
  KEY `idprof` (`idprof`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `tbltrabajosalumnos`
--

INSERT INTO `tbltrabajosalumnos` (`idtrabajo`, `idalumno`, `fecha`, `trabajos`, `comportamientos`, `usuario`, `ipusuario`, `fechamodif`, `usuariomod`, `ipusuariomodif`, `idprof`) VALUES
(1, 2, '2025-07-04 15:41:33', 'El alumno debe terminar los ejercicios que trae de Matemáticas y estudiar el tema 6 de Lengua para un examen el lunes.', 'Es un alumno muy inquieto y hay que estar muy pendiente para que esté concentrado. Debe estar a una hora que no haya muchos alumnos.', 'Araceli', '::1', '2025-07-04', 'Araceli', '::1', 14),
(2, 4, '2025-07-08 15:12:08', 'Tiene que aprender bien las tablas, sobre todo las del 7 y el 9 le cuestan bastante, si es necesario le pones a jugar en alguna de estas webs:\r\nhttps://arbolabc.com/juegos-tablas-de-multiplicar\r\nhttps://www.cokitos.com/tag/tablas-de-multiplicar/', 'Su comportamiento es muy bueno, no protesta por hacer la tarea y suele estar concentrado.', 'Araceli', '::1', '0000-00-00', '', '', 14),
(3, 3, '2025-07-08 15:51:08', 'Debe realizar un repaso a fondo de la parte de matemáticas de álgebra y fracciones.Sobre todo las operaciones con corchetes y paréntesis.', 'Se porta muy bien, siempre que no venga a la misma hora de su primo Manuel.', 'Araceli', '::1', '0000-00-00', '', '', 11);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbltutores`
--

CREATE TABLE IF NOT EXISTS `tbltutores` (
  `idtutor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(75) COLLATE utf8_spanish_ci NOT NULL,
  `usuario` varchar(15) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `password` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(75) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fechalta` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fechamodif` datetime DEFAULT NULL,
  `username` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `usernamemod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `ipusuario` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `ipusuariomod` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idtutor`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `tbltutores`
--

INSERT INTO `tbltutores` (`idtutor`, `nombre`, `usuario`, `password`, `email`, `fechalta`, `fechamodif`, `username`, `usernamemod`, `ipusuario`, `ipusuariomod`, `telefono`) VALUES
(1, 'Antonio Martínez Ramos', 'p.antonio.mr', 'P.ant@Mar2025', 'antonio.maram@gmail.com', '2025-06-24 18:33:28', '2025-06-26 19:36:24', '', 'Araceli', '', '::1', '669528641'),
(2, 'Juan Pablo Lomas Mora', 'p.juanpalomo', '%Juanpa@Lomo%', 'juanpalomo@gmail.com', '2025-06-25 15:54:35', '2025-07-06 17:42:58', '', 'Eli', '', '::1', '693852714'),
(3, 'Bernardo Clarisa Mateo', 'p.bernar.clama-', 'JpAB0W9TEYVq', 'bernarclama@gmail.com', '2025-06-26 16:37:18', NULL, 'Araceli', '', '::1', '', '669325874'),
(4, 'Bernardo Gutiérrez Alma', 'p.bernardo.guti', 'iOsLElnwn2Qg', 'bernar.gutial@gmail.com', '2025-06-26 16:47:13', NULL, 'Araceli', '', '::1', '', '663985214');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `tblcalificaciones`
--
ALTER TABLE `tblcalificaciones`
  ADD CONSTRAINT `tblcalificaciones_ibfk_1` FOREIGN KEY (`idasignat`) REFERENCES `tblasignaturas` (`idasignat`) ON UPDATE CASCADE,
  ADD CONSTRAINT `tblcalificaciones_ibfk_2` FOREIGN KEY (`idalumno`) REFERENCES `tblalumnos` (`idalumno`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbltareasalumnos`
--
ALTER TABLE `tbltareasalumnos`
  ADD CONSTRAINT `tbltareasalumnos_ibfk_1` FOREIGN KEY (`idalumno`) REFERENCES `tblalumnos` (`idalumno`) ON UPDATE CASCADE,
  ADD CONSTRAINT `tbltareasalumnos_ibfk_2` FOREIGN KEY (`idasignatura`) REFERENCES `tblasignaturas` (`idasignat`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbltrabajosalumnos`
--
ALTER TABLE `tbltrabajosalumnos`
  ADD CONSTRAINT `tbltrabajosalumnos_ibfk_1` FOREIGN KEY (`idalumno`) REFERENCES `tblalumnos` (`idalumno`) ON UPDATE CASCADE,
  ADD CONSTRAINT `tbltrabajosalumnos_ibfk_2` FOREIGN KEY (`idprof`) REFERENCES `tblprofesores` (`idprof`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
