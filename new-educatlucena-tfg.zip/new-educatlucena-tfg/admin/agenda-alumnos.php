<?php require_once('../Connections/conexion.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  @session_start();
} 

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "..\index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "..\index.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>

<?php
$maxRows_Lista_Tareas_Alumnos = 15;
$pageNum_Lista_Tareas_Alumnos = 0;
if (isset($_GET['pageNum_Lista_Tareas_Alumnos'])) {
  $pageNum_Lista_Tareas_Alumnos = $_GET['pageNum_Lista_Tareas_Alumnos'];
}
$startRow_Lista_Tareas_Alumnos = $pageNum_Lista_Tareas_Alumnos * $maxRows_Lista_Tareas_Alumnos;

if (isset($_GET['busqueda']) && $_GET['busqueda'] !== "") {
  $colname_Lista_Tareas_Alumnos = $_GET['busqueda'];
} elseif (isset($_SESSION['idalumno'])) {
  $colname_Lista_Tareas_Alumnos = $_SESSION['idalumno'];
} else {
  $colname_Lista_Tareas_Alumnos = "-1";
}

$codigoalumno= $_SESSION['idalumno'];
mysql_select_db($database_conexion, $conexion);
$query_Lista_Tareas_Alumnos = sprintf("SELECT * FROM tbltareasalumnos WHERE tbltareasalumnos.idalumno = $codigoalumno ORDER BY tbltareasalumnos.idtarea DESC", GetSQLValueString("%" . $colname_Lista_Tareas_Alumnos . "%", "text"));
$query_limit_Lista_Tareas_Alumnos = sprintf("%s LIMIT %d, %d", $query_Lista_Tareas_Alumnos, $startRow_Lista_Tareas_Alumnos, $maxRows_Lista_Tareas_Alumnos);
$Lista_Tareas_Alumnos = mysql_query($query_limit_Lista_Tareas_Alumnos, $conexion) or die(mysql_error());
$row_Lista_Tareas_Alumnos = mysql_fetch_assoc($Lista_Tareas_Alumnos);

if (isset($_GET['totalRows_Lista_Tareas_Alumnos'])) {
  $totalRows_Lista_Tareas_Alumnos = $_GET['totalRows_Lista_Tareas_Alumnos'];
} else {
  $all_Lista_Tareas_Alumnos = mysql_query($query_Lista_Tareas_Alumnos);
  $totalRows_Lista_Tareas_Alumnos = mysql_num_rows($all_Lista_Tareas_Alumnos);
}
$totalPages_Lista_Tareas_Alumnos = ceil($totalRows_Lista_Tareas_Alumnos/$maxRows_Lista_Tareas_Alumnos)-1;

$currentPage = $_SERVER["PHP_SELF"];

mysql_select_db($database_conexion, $conexion);
$query_Lista_Asignaturas = "SELECT * FROM tblasignaturas ";
$Lista_Asignaturas = mysql_query($query_Lista_Asignaturas, $conexion) or die(mysql_error());
$row_Lista_Asignaturas = mysql_fetch_assoc($Lista_Asignaturas);
$totalRows_Lista_Asignaturas = mysql_num_rows($Lista_Asignaturas);

mysql_select_db($database_conexion, $conexion);
$query_Lista_Alumnos = "SELECT * FROM tblalumnos WHERE tblalumnos.activo = 1";
$Lista_Alumnos = mysql_query($query_Lista_Alumnos, $conexion) or die(mysql_error());
$row_Lista_Alumnos = mysql_fetch_assoc($Lista_Alumnos);
$totalRows_Lista_Alumnos = mysql_num_rows($Lista_Alumnos);

$queryString_Lista_Tareas_Alumnos = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_Lista_Tareas_Alumnos") == false && 
        stristr($param, "totalRows_Lista_Tareas_Alumnos") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_Lista_Tareas_Alumnos = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_Lista_Tareas_Alumnos = sprintf("&totalRows_Lista_Tareas_Alumnos=%d%s", $totalRows_Lista_Tareas_Alumnos, $queryString_Lista_Tareas_Alumnos);
?>
<!doctype html>
<html>
<head>
 <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>..:: Panel de Control - EducaTLucena ::..</title>
	<link rel="shortcut icon" href="../imagenes/favicon.ico">
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="assets/css/style.css" rel="stylesheet" />
    <style type="text/css">
body,td,th {
	font-family: Raleway, sans-serif;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
	color: #000000;
}
a:active {
	text-decoration: none;
}
footer {
	  background-color: #dee2e6;
	  color: #212529;
	  padding: 20px 0;
	  text-align: center;
	  margin-top: 200px;
}
</style>
</head>
<body>
<div id="wrapper">
      <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a  class="navbar-brand" href="#">Panel de Control 

                </a>
          </div>
      </nav> 
        <!-- /. SIDEBAR MENU (navbar-side) -->
        
        <?php include ("includes/menu-alumnos.php"); ?>
        
        <!-- /. END SIDEBAR MENU (navbar-side) -->
               
        <div id="page-wrapper" class="page-wrapper-cls">
        

        
           <div id="page-inner">
                
                        
                <div class="row">
        
                    <div class="col-md-12">
					
						<img src="imagenes/logotipo.png" width="325" height="105" style="margin-left: 30px;"  />
        
                    	<h2>Bienvenido a EducaTLucena</h2>
        
                        <div class="alert alert-warning">
<section>
<br>
<div id="listados">
  <?php if ($totalRows_Lista_Tareas_Alumnos > 0) { // Show if recordset not empty ?>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    
    
</div>
      <td align="center" >&nbsp;</td>
      
            <option value="<?php // echo $row_Lista_Alumnos['idalumno']?>"><?php // echo $row_Lista_Alumnos['nombre']?></option>
            <?php
} while ($row_Lista_Alumnos = mysql_fetch_assoc($Lista_Alumnos));
  $rows = mysql_num_rows($Lista_Alumnos);
  if($rows > 0) {
      mysql_data_seek($Lista_Alumnos, 0);
	  $row_Lista_Alumnos = mysql_fetch_assoc($Lista_Alumnos);
  }
  
?>
          </select></span>
     
      </form></td>
      </tr>
    <tr class="titulolistados">
      <td align="center" >&nbsp;</td>
      <td align="center" >&nbsp;</td>
      <td align="center" >&nbsp;</td>
      <td align="center" >&nbsp;</td>
      <td align="center" >&nbsp;</td>
	  <td align="center" >&nbsp;</td>
      <td colspan="3" align="center" >&nbsp;</td>
    </tr>
   <tr class="titulolistados">
      <td width="15%" align="center"><strong>Nombre y Apellidos</strong></td>
      <td width="10%" align="center"><strong>Asignatura</strong></td>
      <td width="20%" align="center"><strong>Sobre la Web</strong></td>
      <td width="15%" align="center"><strong>Direcci�n Web</strong></td>
	  <td width="25%" align="center"><strong>Comentarios</strong></td>
      <td width="5%" align="center"><strong>Documento<strong></td>
   </tr>
    <?php do { ?>
      <tr class="contenidolistado">
        <td height="30"><?php echo nombrealumno ($row_Lista_Tareas_Alumnos['idalumno']); ?></td>
        <td><?php echo nombreasignatura ($row_Lista_Tareas_Alumnos['idasignatura']); ?></td>
        <td align="center"><?php echo $row_Lista_Tareas_Alumnos['acercadelaweb']; ?></td>
        <td align="center"><a href="<?php echo $row_Lista_Tareas_Alumnos['url']; ?>" target="_blank"><?php echo $row_Lista_Tareas_Alumnos['url']; ?></a></td>
		<td align="center"><?php echo substr ($row_Lista_Tareas_Alumnos['comentarios'], 0, 75)."..."; ?></td>
        <td align="center"><a href="documentacion-alumnos/<?php echo $row_Lista_Tareas_Alumnos['adjunto']; ?>" target="_blank">
		
        <?php 
        if (empty ($row_Lista_Tareas_Alumnos['adjunto']))
		{
		echo " ";
		}
		else
		{
		?>
        <img src="../imagenes/descarga.jpg" width="20" height="20"></a><?php } ?></td>
        
      </tr>
      <?php } while ($row_Lista_Tareas_Alumnos = mysql_fetch_assoc($Lista_Tareas_Alumnos)); ?>
  </table>

  
</div>
<?php if ($totalRows_Lista_Tareas_Alumnos == 0) { // Show if recordset empty ?>
  <div align="center" class="titulolistados">No existen tareas de alumnos en la Base de Datos con la informacion introducida. <br>
    Pulsa <span style="text-decoration: none;color: #00C; font-weight:bold;"><a href="alta-tareas-alumnos.php">aqui</a></span> para crear uno &oacute; <a href="listado-tareas-alumnos.php"><span style="text-decoration: none;color: #00C; font-weight:bold;">int&eacute;ntalo de nuevo</span></a></div>
  <?php } // Show if recordset empty ?>

<table border="0" align="center" cellpadding="5" cellspacing="5">
  <tr>
    <td><?php if ($pageNum_Lista_Tareas_Alumnos > 0) { // Show if not first page ?>
        <a href="<?php printf("%s?pageNum_Lista_Tareas_Alumnos=%d%s", $currentPage, 0, $queryString_Lista_Tareas_Alumnos); ?>"><img src="../imagenes/primero.png" alt="Imagen Primero"></a>
        <?php } // Show if not first page ?></td>
    <td><?php if ($pageNum_Lista_Tareas_Alumnos > 0) { // Show if not first page ?>
        <a href="<?php printf("%s?pageNum_Lista_Tareas_Alumnos=%d%s", $currentPage, max(0, $pageNum_Lista_Tareas_Alumnos - 1), $queryString_Lista_Tareas_Alumnos); ?>"><img src="../imagenes/anterior.png" alt="Imagen Anterior"></a>
        <?php } // Show if not first page ?></td>
    <td><?php if ($pageNum_Lista_Tareas_Alumnos < $totalPages_Lista_Tareas_Alumnos) { // Show if not last page ?>
        <a href="<?php printf("%s?pageNum_Lista_Tareas_Alumnos=%d%s", $currentPage, min($totalPages_Lista_Tareas_Alumnos, $pageNum_Lista_Tareas_Alumnos + 1), $queryString_Lista_Tareas_Alumnos); ?>"><img src="../imagenes/siguiente.png" alt="Imagen Siguiente"></a>
        <?php } // Show if not last page ?></td>
    <td><?php if ($pageNum_Lista_Tareas_Alumnos < $totalPages_Lista_Tareas_Alumnos) { // Show if not last page ?>
        <a href="<?php printf("%s?pageNum_Lista_Tareas_Alumnos=%d%s", $currentPage, $totalPages_Lista_Tareas_Alumnos, $queryString_Lista_Tareas_Alumnos); ?>"><img src="../imagenes/ultimo.png" alt="Imagen Ultimo"></a>
        <?php } // Show if not last page ?></td>
  </tr>
</table>
</section>
<!-- /. WRAPPER  -->

  <footer class="text-center text-muted py-3">
    &copy; 2025 EducaTLucena. Todos los derechos reservados.
  </footer>
  <!-- A�o din�mico -->
  <script>
    document.getElementById("year").textContent = new Date().getFullYear();
  </script>
  
    
    <!-- /. FOOTER  -->
    
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
<?php
mysql_free_result($Lista_Tareas_Alumnos);

mysql_free_result($Lista_Asignaturas);

mysql_free_result($Lista_Alumnos);
?>