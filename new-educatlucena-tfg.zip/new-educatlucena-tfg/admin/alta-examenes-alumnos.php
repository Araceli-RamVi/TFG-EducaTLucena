<?php require_once('../Connections/conexion.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "login.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO tbltareasalumnos (idalumno, idasignatura, adjunto, comentarios, acercadelaweb, url, username, ipusuario) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['idalumno'], "int"),
					   GetSQLValueString($_POST['idasignatura'], "int"),
                       GetSQLValueString($_POST['adjunto'], "text"),
                       GetSQLValueString($_POST['comentarios'], "text"),
                       GetSQLValueString($_POST['acercadelaweb'], "text"),
                       GetSQLValueString($_POST['url'], "text"),
                       GetSQLValueString($_POST['username'], "text"),
                       GetSQLValueString(getRealIP($_POST['ipusuario']), "text"));

  mysql_select_db($database_conexion, $conexion);
  $Result1 = mysql_query($insertSQL, $conexion) or die(mysql_error());

  $insertGoTo = "listado-tareas-alumnos.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_conexion, $conexion);
$query_Lista_Tareas_Alumnos = "SELECT * FROM tbltareasalumnos";
$Lista_Tareas_Alumnos = mysql_query($query_Lista_Tareas_Alumnos, $conexion) or die(mysql_error());
$row_Lista_Tareas_Alumnos = mysql_fetch_assoc($Lista_Tareas_Alumnos);
$totalRows_Lista_Tareas_Alumnos = mysql_num_rows($Lista_Tareas_Alumnos);

mysql_select_db($database_conexion, $conexion);
$query_Lista_Alumnos = "SELECT * FROM tblalumnos WHERE tblalumnos.activo = 1";
$Lista_Alumnos = mysql_query($query_Lista_Alumnos, $conexion) or die(mysql_error());
$row_Lista_Alumnos = mysql_fetch_assoc($Lista_Alumnos);
$totalRows_Lista_Alumnos = mysql_num_rows($Lista_Alumnos);

mysql_select_db($database_conexion, $conexion);
$query_Lista_Asignaturas = "SELECT * FROM tblasignaturas";
$Lista_Asignaturas = mysql_query($query_Lista_Asignaturas, $conexion) or die(mysql_error());
$row_Lista_Asignaturas = mysql_fetch_assoc($Lista_Asignaturas);
$totalRows_Lista_Asignaturas = mysql_num_rows($Lista_Asignaturas);

error_reporting(0);
$fecha1 = date('Y-m-d', strtotime($_POST['Fechaexamen']));
?>
<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>..:: Panel de Control - EducaTLucena ::..</title>
	<link rel="shortcut icon" href="../imagenes/favicon.ico">
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="assets/css/style.css" rel="stylesheet" />
    <style type="text/css">

body,td,th {
	font-family: Raleway, sans-serif;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
	color: #000000;
}
a:active {
	text-decoration: none;
}
footer {
	  background-color: #dee2e6;
	  color: #212529;
	  padding: 20px 0;
	  text-align: center;
	  margin-top: 200px;
}
<script language="JavaScript"> 
function asegurar ()
  {
      rc = confirm("�Desea dar de alta esta tarea?");
      return rc;
  } 
</script>
<script >
function subirimagen()
{
	self.name = 'opener';
	remote = open('gestion-archivos-alumnos.php', 'remote', 'width=500,height=150,location=no,scrollbars=yes,menubars=no,toolbars=no,resizable=yes,fullscreen=no, status=yes');
 	remote.focus();
}
</script>

</head>
<body>
<div id="contenedor">
<?php include ("includes/header-admin.php"); ?>
<div id="logueo">
Bienvenid@: <?php echo $_SESSION['MM_Username'] ?><br/><a href="<?php echo $logoutAction ?>" class="desconexion">(Cerrar Sesi&oacute;n)</a>
</div>
<nav>
<?php include ("menu.php"); ?>
</nav>
<section>
<br>
<div id="listados">
  <form action="<?php echo $editFormAction; ?>" method="POST" name="form1">
    <table width="510" align="center">
      <tr valign="baseline">
        <td nowrap align="right">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="2" align="center" nowrap bgcolor="#FFF380"><h3>Alta de Tareas de Alumnos</h3></td>
        </tr>
      <tr valign="baseline">
        <td nowrap align="right">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="left">Alumno:</td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="2" align="left" nowrap><span id="students">
          <select name="idalumno" id="idalumno">
            <option value="" >Selecciona Alumno</option>
            <?php
do {  
?>
            <option value="<?php echo $row_Lista_Alumnos['idalumno']?>"><?php echo $row_Lista_Alumnos['nombre']?></option>
            <?php
} while ($row_Lista_Alumnos = mysql_fetch_assoc($Lista_Alumnos));
  $rows = mysql_num_rows($Lista_Alumnos);
  if($rows > 0) {
      mysql_data_seek($Lista_Alumnos, 0);
	  $row_Lista_Alumnos = mysql_fetch_assoc($Lista_Alumnos);
  }
?>
          </select>
          </span></td>
        </tr>
      <tr valign="baseline">
        <td nowrap align="left">Asignatura:</td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="2" align="left" nowrap><span id="signature">
          <select name="idasignatura" id="idasignatura">
            <option value="" >Selecciona una Asignatura</option>
            <?php
do {  
?>
            <option value="<?php echo $row_Lista_Asignaturas['idasignat']?>"><?php echo $row_Lista_Asignaturas['nombreasignat']?></option>
            <?php
} while ($row_Lista_Asignaturas = mysql_fetch_assoc($Lista_Asignaturas));
  $rows = mysql_num_rows($Lista_Asignaturas);
  if($rows > 0) {
      mysql_data_seek($Lista_Asignaturas, 0);
	  $row_Lista_Asignaturas = mysql_fetch_assoc($Lista_Asignaturas);
  }
?>
          </select>
          </span></td>
        </tr>
      <tr valign="baseline">
        <td nowrap align="left">Adjunto</td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="2" align="left" nowrap>
          <input name="adjunto" type="text" id="adjunto" value="" size="32" readonly /> <input type="button" name="button" id="button" value="Subir Archivo" onclick="javascript:subirimagen();"/></td>
        </tr>
      <tr valign="baseline">
        <td nowrap align="left">Acerca de la Web:</td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="left"><input name="acercadelaweb" type="text" id="acercadelaweb" size="32"></td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="left">Direccion web:</td>
        <td>&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="2" align="left" nowrap><input name="url" type="text" id="url" size="32"></td>
        </tr>
      <tr valign="baseline">
        <td nowrap align="left">Comentarios:</td>
        <td align="right">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="2" align="left" nowrap><textarea name="comentarios" cols="70" rows="5" id="comentarios"></textarea></td>
        </tr>
      <tr valign="baseline">
        <td nowrap align="right">&nbsp;</td>
        <td align="right">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right"><input type="hidden" name="username" id="username" value="<?php echo $_SESSION['MM_Username']?>"><input type="hidden" name="ipusuario" id="ipusuario"></td>
        <td align="right"><input type="submit" onclick="javascript:return asegurar();" value="Insertar registro"></td>
      </tr>
    </table>
    <input type="hidden" name="MM_insert" value="form1">
  </form>

</div>
<br>
</section>

  <!-- /. WRAPPER  -->
	
	 <!-- /. FOOTER  -->
    
   <footer class="text-center text-muted py-3">
    &copy; 2025 EducaTLucena. Todos los derechos reservados.
  </footer>
  <!-- A�o din�mico -->
  <script>
    document.getElementById("year").textContent = new Date().getFullYear();
  </script>
  
    
    <!-- /. FOOTER  -->
    
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
<?php
mysql_free_result($Lista_Tareas_Alumnos);

mysql_free_result($Lista_Alumnos);

mysql_free_result($Lista_Asignaturas);
?>