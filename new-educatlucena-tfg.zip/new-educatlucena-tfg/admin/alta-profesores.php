<?php require_once('../Connections/conexion.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  @session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "../login.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "../login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}



// *** Redirect if usuario o email exists
$MM_flag="MM_insert";
if (isset($_POST[$MM_flag])) {
  $MM_dupKeyRedirect="usuario-profesor-existe.php";
  $loginUsername = $_POST['usuario'];
  $correo = $_POST['email'];
  $telefono = $_POST['telefono'];
  $LoginRS__query = sprintf("SELECT usuario FROM tblprofesores WHERE usuario=%s OR email=%s OR telefono=%s", 
  GetSQLValueString($loginUsername, "text"),
  GetSQLValueString($correo, "text"),
  GetSQLValueString($telefono, "text"));
  mysql_select_db($database_conexion, $conexion);
  $LoginRS=mysql_query($LoginRS__query, $conexion) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);

  //if there is a row in the database, the username was found - can not add the requested username
  if($loginFoundUser){
    $MM_qsChar = "?";
    //append the username to the redirect page
    if (substr_count($MM_dupKeyRedirect,"?") >=1) $MM_qsChar = "&";
    $MM_dupKeyRedirect = $MM_dupKeyRedirect . $MM_qsChar ."requsername=".$loginUsername;
    header ("Location: $MM_dupKeyRedirect");
    exit;
  }
}

mysql_select_db($database_conexion, $conexion);
$query_Listado_Usuarios = "SELECT * FROM tblprofesores";
$Listado_Usuarios = mysql_query($query_Listado_Usuarios, $conexion) or die(mysql_error());
$row_Listado_Usuarios = mysql_fetch_assoc($Listado_Usuarios);
$totalRows_Listado_Usuarios = mysql_num_rows($Listado_Usuarios);

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO tblprofesores (nombre, usuario, password, email, fechalta, observaciones, telefono, username, ipusuario) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['nombre'], "text"),
                       GetSQLValueString($_POST['usuario'], "text"),
                       GetSQLValueString($_POST['password'], "text"),
                       GetSQLValueString($_POST['email'], "text"),
					   GetSQLValueString($_POST['fechalta'], "date"),
                       GetSQLValueString($_POST['observaciones'], "text"),
					   GetSQLValueString($_POST['telefono'], "text"),
					   GetSQLValueString($_POST['username'], "text"),
					   GetSQLValueString(getRealIP($_POST['ipusuario']), "text"));
  mysql_select_db($database_conexion, $conexion);
  $Result1 = mysql_query($insertSQL, $conexion) or die(mysql_error());

  $insertGoTo = "alta-profesores.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?>

<?php
$currentPage = $_SERVER["PHP_SELF"];

$maxRows_Consulta_Profesores = 15;
$pageNum_Consulta_Profesores = 0;
if (isset($_GET['pageNum_Consulta_Profesores'])) {
  $pageNum_Consulta_Profesores = $_GET['pageNum_Consulta_Profesores'];
}
$startRow_Consulta_Profesores = $pageNum_Consulta_Profesores * $maxRows_Consulta_Profesores;

mysql_select_db($database_conexion, $conexion);
$query_Consulta_Profesores = "SELECT * FROM tblprofesores WHERE idprof>1";
$query_limit_Consulta_Profesores = sprintf("%s LIMIT %d, %d", $query_Consulta_Profesores, $startRow_Consulta_Profesores, $maxRows_Consulta_Profesores);
$Consulta_Profesores = mysql_query($query_limit_Consulta_Profesores, $conexion) or die(mysql_error());
$row_Consulta_Profesores = mysql_fetch_assoc($Consulta_Profesores);

if (isset($_GET['totalRows_Consulta_Profesores'])) {
  $totalRows_Consulta_Profesores = $_GET['totalRows_Consulta_Profesores'];
} else {
  $all_Consulta_Profesores = mysql_query($query_Consulta_Profesores);
  $totalRows_Consulta_Profesores = mysql_num_rows($all_Consulta_Profesores);
}
$totalPages_Consulta_Profesores = ceil($totalRows_Consulta_Profesores/$maxRows_Consulta_Profesores)-1;

$queryString_Consulta_Profesores = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_Consulta_Profesores") == false && 
        stristr($param, "totalRows_Consulta_Profesores") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_Consulta_Profesores = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_Consulta_Profesores = sprintf("&totalRows_Consulta_Profesores=%d%s", $totalRows_Consulta_Profesores, $queryString_Consulta_Profesores);
?>

<!DOCTYPE html>
<html>
<head>
 <!--<meta charset="UTF-8"/>-->
<meta http-equiv="Content-Type" content="text/html; charset="utf-8" />
  
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>..:: Panel de Control - EducaTLucena ::..</title>
	<link rel="shortcut icon" href="../imagenes/favicon.ico">
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="assets/css/style.css" rel="stylesheet" />
    <style type="text/css">
body,td,th {
	font-family: Raleway, sans-serif;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
	color: #000000;
}
a:active {
	text-decoration: none;
}
footer {
	  background-color: #dee2e6;
	  color: #212529;
	  padding: 20px 0;
	  text-align: center;
	  margin-top: 200px;
}
    </style>
      <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<script language="JavaScript"> 
	function asegurar ()
	{
      rc = confirm("¿Desea dar de alta este profesor?");
      return rc;
	}
	</script>
	<script>
	function asegurar2 ()
	  {
		  rc = confirm("¿Seguro que desea eliminar definitivamente el usuario?");
		  return rc;
	  }
	</script>
	<script src="ckeditor/ckeditor.js"></script>
</head>
<body>
    <div id="wrapper">
      <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a  class="navbar-brand" href="#">Panel de Control 

                </a>
          </div>
      </nav> 
        <!-- /. SIDEBAR MENU (navbar-side) -->
        
        <?php include ("includes/menu.php"); ?>
        
        <!-- /. END SIDEBAR MENU (navbar-side) -->
               
        <div id="page-wrapper" class="page-wrapper-cls">
        

        
           <div id="page-inner">
                
                        
                <div class="row">
        
                    <div class="col-md-12">
					
						<img src="imagenes/logotipo.png" width="325" height="105" style="margin-left: 30px;"  />
        
                    	<h2>Bienvenido a EducaTLucena</h2>
        
                        <div class="alert alert-warning">
        
                           
						   
						   
                        
                         <?php if (isset($_GET["estado"])) {

								if ($_GET["estado"]== 1) { ?>
						
						
                          <div class="alert alert-success" role="alert">
  						  <h4 class="alert-heading" style="text-align:center;">Bien Hecho <?php echo $_SESSION['MM_Username']; echo "&nbsp;";?>!</h4>
                          <h5 style="padding-bottom:-7px; text-align:center"> El profesor se ha creado correctamente.</h5>
                          </div>
                          
                          <?php  }  }
						  
						  ?>
						   
						   
						  <form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1" autocomplete="onclick">
        
                           <div id="accordion">
 		                   
                            <input name="usuario" type="hidden" id="usuario" value="<?php echo $_SESSION['MM_Username'];  ?>" />
                            
                      
                            <h4><strong>Gesti&oacute;n de Profesores - Alta</strong></h4><hr>
                            
                            <div class="row"> 
                            
                            <div class="form-group col-md-3">
                            
                            <label>Nombre Completo:</label>
                            
                            <input name="nombre" class="form-control"  type="text" id="name" value="" size="25" placeholder="" required/>
                            
                            </div>
                            
                            <div class="form-group col-md-3">
                            
                            <label>Email:</label>
                            
                            <input name="email" class="form-control"  type="text" id="correo" value="" size="62" maxlength="62" placeholder="" required/>
                            
                            </div>
                                                
                            </div>
                            
                            <div class="row">
                                
                            <div class="form-group col-md-3">
                            
                            <label>Usuario:</label>
                            
                            <input name="usuario" class="form-control"  type="text" id="user" size="25" placeholder="" required/>
                            
                            </div>
                            
                            <div class="form-group col-md-3">
                            
                            <label>Contrase&ntilde;a:</label>
                            
                            <input name="password" class="form-control"  type="text" id="pass" value="" size="25"  placeholder="" required/>
                            
                            </div>
                                                       
                            </div>
                            
                            <div class="row">
                            
                            <div class="form-group col-md-3">
                            
                            <label>Tel&eacute;fono:</label>
                            
                            <input name="telefono" class="form-control"  type="text" id="phone" value="" size="25" placeholder="" required/>
                            
                            </div>
                                                       
                            <div class="row">
                            
                            <div class="form-group col-md-12">
                            
                            <label>Observaciones:</label>
                            
                            <textarea name="observaciones" class="form-control" rows="5" placeholder=""></textarea>
							
							<input type="hidden" name="username" id="username" value="<?php echo $_SESSION['MM_Username']?>">
							
							<input type="hidden" name="ipusuario" id="ipusuario">
                            
                            </div> 
                            
                            </div>
                            
                            <input type="hidden" name="fechalta" value="">
      						
                            <input type="hidden" name="MM_insert" value="form1" />
                                              
                            </div>
   
                            <input type="submit" value="Alta de Profesor" onclick="javascript:return asegurar();">
                            
							
                            
                            </form>
						  
                            </p> 
							
							<br><br>

<h4>Listado Profesores</h4><hr>
<div class="table-responsive">
                          <div id="listados">
  <?php if ($totalRows_Consulta_Profesores > 0) { // Show if recordset not empty ?>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
       
    <tr class="titulolistados">
      <td width="18%" align="center">Nombre y Apellidos</td>
      <td width="19%" align="center">Usuario</td>
      <td width="22%" align="center">Email</td>
      <td width="18%" align="center">Teléfono</td>
      <td colspan="2" align="center"><?php
        if ( ($_SESSION['MM_Username'] == "Araceli") || ($_SESSION['MM_Username'] == "Eli") || ($_SESSION['MM_Username'] == "ADMINISTRADOR")){
		echo 'Acciones'; 
		}
		else 
		{echo "";
		}
		?></td>
    </tr>
    <?php do { ?>
      <tr class="contenidolistado">
        <td height="30" align="center"><?php echo $row_Consulta_Profesores['nombre']; ?></td>
        <td align="center"><?php echo $row_Consulta_Profesores['usuario']; ?></td>
        <td align="center"><?php echo $row_Consulta_Profesores['email']; ?></td>
        <td align="center"><?php echo $row_Consulta_Profesores['telefono']; ?></td>
        <td width="3%"><a href="edit-profesores.php?Profesor=<?php echo $row_Consulta_Profesores['idprof']; ?>">
        <?php
        if ( ($_SESSION['MM_Username'] == "Araceli") || ($_SESSION['MM_Username'] == "Eli") || ($_SESSION['MM_Username'] == "ADMINISTRADOR")){
		echo '<img src="../imagenes/1.jpg" width="23" height="23" alt="Imagen Editar">'; 
		}
		else {
		echo "";
		}
		?>
        </a></td>
        <td width="3%"><a href="borrar-profesores.php?Profesor=<?php echo $row_Consulta_Profesores['idprof']; ?>" onclick="javascript:return asegurar2();">
        <?php
        if ( ($_SESSION['MM_Username'] == "Araceli") || ($_SESSION['MM_Username'] == "Eli") || ($_SESSION['MM_Username'] == "ADMINISTRADOR")){
		echo '<img src="../imagenes/2.png" width="22" height="23" alt="Imagen Eliminar">'; 
		}
		else {
		echo "";
		}
		?>
        </a></td>
      </tr>
      <?php } while ($row_Consulta_Profesores = mysql_fetch_assoc($Consulta_Profesores)); ?>
  </table>
 
    <div style="font-family: 'Palatino Linotype', 'Book Antiqua', Palatino, serif; font-weight: bold; font-size: 14px; border-top: #CCC 1px solid; border-bottom: #CCC 1px solid;">EducaTlucena esta mostrando del profesor <?php echo ($startRow_Consulta_Profesores + 1) ?> al <?php echo min($startRow_Consulta_Profesores + $maxRows_Consulta_Profesores, $totalRows_Consulta_Profesores) ?> de <?php echo $totalRows_Consulta_Profesores ?> profesores.</div>
 
<?php } // Show if recordset not empty ?>
  
</div>
<?php if ($totalRows_Consulta_Profesores == 0) { // Show if recordset empty ?>
  <div align="center" class="titulolistados">No existen profesores en la Base de Datos. Pulsa <a href="alta-profesores.php"><span style="text-decoration: none;color: #00C; font-weight:bold;">aquí</span></a> para crear uno</div>
  <?php } // Show if recordset empty ?>

<table border="0" align="center" cellpadding="5" cellspacing="5">
  <tr>
    <td><?php if ($pageNum_Consulta_Profesores > 0) { // Show if not first page ?>
        <a href="<?php printf("%s?pageNum_Consulta_Profesores=%d%s", $currentPage, 0, $queryString_Consulta_Profesores); ?>"><img src="../imagenes/primero.png" alt="Imagen Primero"></a>
        <?php } // Show if not first page ?></td>
    <td><?php if ($pageNum_Consulta_Profesores > 0) { // Show if not first page ?>
        <a href="<?php printf("%s?pageNum_Consulta_Profesores=%d%s", $currentPage, max(0, $pageNum_Consulta_Profesores - 1), $queryString_Consulta_Profesores); ?>"><img src="../imagenes/anterior.png" alt="Imagen Anterior"></a>
        <?php } // Show if not first page ?></td>
    <td><?php if ($pageNum_Consulta_Profesores < $totalPages_Consulta_Profesores) { // Show if not last page ?>
        <a href="<?php printf("%s?pageNum_Consulta_Profesores=%d%s", $currentPage, min($totalPages_Consulta_Profesores, $pageNum_Consulta_Profesores + 1), $queryString_Consulta_Profesores); ?>"><img src="../imagenes/siguiente.png" alt="Imagen Siguiente"></a>
        <?php } // Show if not last page ?></td>
    <td><?php if ($pageNum_Consulta_Profesores < $totalPages_Consulta_Profesores) { // Show if not last page ?>
        <a href="<?php printf("%s?pageNum_Consulta_Profesores=%d%s", $currentPage, $totalPages_Consulta_Profesores, $queryString_Consulta_Profesores); ?>"><img src="../imagenes/ultimo.png" alt="Imagen Ultimo"></a>
        <?php } // Show if not last page ?></td>
  </tr>
</table>
                      </div>
	
	
	
	
    
        
                        </div>
        
                    </div>
        
                </div>

            </div>
    
            <!-- /. PAGE INNER  -->
    
        </div>
    
        <!-- /. PAGE WRAPPER  -->
			    
	
    </div>

	
    <!-- /. WRAPPER  -->
    
   <footer class="text-center text-muted py-3">
    &copy; 2025 EducaTLucena. Todos los derechos reservados.
  </footer>
  <!-- Año dinámico -->
  <script>
    document.getElementById("year").textContent = new Date().getFullYear();
  </script>
  
    
    <!-- /. FOOTER  -->
    
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
	

</body>
</html>
<?php
mysql_free_result($Consulta_Profesores);

mysql_free_result($Listado_Usuarios);
?>
